import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../util.dart';

const methods = ['Cash', 'Card', 'Mobile Money', 'Bank Transfer'];

/// 4. Product / Item Selection
class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  String q = '', cat = 'All';

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cats = ['All', ...{...s.products.map((p) => p.category)}];
    final list = s.products.where((p) => (cat == 'All' || p.category == cat) && p.name.toLowerCase().contains(q.toLowerCase())).toList();
    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(children: [
            const Align(alignment: Alignment.centerLeft, child: Text('Products', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
            const SizedBox(height: 8),
            TextField(onChanged: (v) => setState(() => q = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search products...')),
            const SizedBox(height: 8),
            SizedBox(
              height: 38,
              child: ListView(scrollDirection: Axis.horizontal, children: [
                for (final c in cats)
                  Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(c), selected: cat == c, onSelected: (_) => setState(() => cat = c))),
              ]),
            ),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: list.length,
            itemBuilder: (_, i) {
              final p = list[i];
              final inCart = s.cart[p.id]?.qty ?? 0;
              return Card(
                child: ListTile(
                  leading: CircleAvatar(backgroundColor: Colors.blue.shade50, child: const Icon(Icons.local_drink_outlined)),
                  title: Text(p.name),
                  subtitle: Text('${ugx(p.price)}\nStock: ${p.stock}'),
                  isThreeLine: true,
                  trailing: Badge(
                    isLabelVisible: inCart > 0, label: Text('$inCart'),
                    child: IconButton.filled(onPressed: p.stock == 0 ? null : () => s.addToCart(p), icon: const Icon(Icons.add)),
                  ),
                ),
              );
            },
          ),
        ),
        if (s.cartCount > 0)
          Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckoutScreen())),
              child: Text('View Cart (${s.cartCount}) - ${ugx(s.total)}'),
            ),
          ),
      ]),
    );
  }
}

/// 5. Create Sale / Checkout
class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (s.cart.isEmpty) {
      return Scaffold(appBar: AppBar(title: const Text('New Sale')), body: const Center(child: Text('Cart is empty')));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('New Sale')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.person_outline),
            title: Text(s.customer?.name ?? 'Walk-in Customer'),
            trailing: TextButton(onPressed: () => _pickCustomer(context), child: const Text('Change')),
          ),
        ),
        for (final l in s.cart.values)
          Card(
            child: ListTile(
              leading: const Icon(Icons.shopping_bag_outlined),
              title: Text(l.product.name),
              subtitle: Row(children: [
                Text(ugx(l.product.price)),
                const SizedBox(width: 8),
                IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.remove_circle_outline), onPressed: () => s.changeQty(l.product, -1)),
                Text('${l.qty}'),
                IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.add_circle_outline), onPressed: () => s.changeQty(l.product, 1)),
              ]),
              trailing: Text(ugx(l.total), style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
          ),
        const Divider(height: 32),
        _row('Subtotal', ugx(s.subtotal)),
        _row('Tax (${s.taxRate}%)', ugx(s.tax)),
        _row('Total', ugx(s.total), bold: true),
        const SizedBox(height: 16),
        const Text('Payment Method', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final m in methods) ChoiceChip(label: Text(m), selected: s.method == m, onSelected: (_) => s.setMethod(m)),
        ]),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PaymentScreen())),
          child: const Text('Complete Sale'),
        ),
        TextButton(onPressed: s.clearCart, child: const Text('Clear cart')),
      ]),
    );
  }

  Widget _row(String a, String b, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(a, style: TextStyle(fontWeight: bold ? FontWeight.bold : null, fontSize: bold ? 18 : 14)),
          Text(b, style: TextStyle(fontWeight: bold ? FontWeight.bold : null, fontSize: bold ? 18 : 14)),
        ]),
      );

  void _pickCustomer(BuildContext context) {
    final s = context.read<AppState>();
    showModalBottomSheet(
      context: context,
      builder: (_) => ListView(children: [
        ListTile(leading: const Icon(Icons.person_outline), title: const Text('Walk-in Customer'), onTap: () { s.setCustomer(null); Navigator.pop(context); }),
        for (final c in s.customers)
          ListTile(leading: const Icon(Icons.person), title: Text(c.name), subtitle: Text(c.phone), onTap: () { s.setCustomer(c); Navigator.pop(context); }),
      ]),
    );
  }
}

/// 6. Payment Methods
class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});
  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final tendered = TextEditingController(), phone = TextEditingController(), ref = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final m = s.method;
    final paid = int.tryParse(tendered.text) ?? 0;
    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Center(child: Text('Total Amount')),
        Center(child: Text(ugx(s.total), style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        for (final x in methods)
          Card(
            color: m == x ? Theme.of(context).colorScheme.primaryContainer : null,
            child: ListTile(
              leading: Icon(switch (x) { 'Card' => Icons.credit_card, 'Mobile Money' => Icons.phone_android, 'Bank Transfer' => Icons.account_balance, _ => Icons.payments }),
              title: Text(x == 'Card' ? 'Credit / Debit Card' : x == 'Mobile Money' ? 'Mobile Money (MTN / Airtel)' : x),
              trailing: m == x ? const Icon(Icons.check_circle) : null,
              onTap: () => s.setMethod(x),
            ),
          ),
        const SizedBox(height: 8),
        if (m == 'Cash') ...[
          TextField(controller: tendered, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'Amount received (UGX)')),
          if (paid >= s.total) Padding(padding: const EdgeInsets.all(8), child: Text('Change: ${ugx(paid - s.total)}', style: const TextStyle(fontWeight: FontWeight.bold))),
        ],
        if (m == 'Mobile Money')
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Customer phone (e.g. 0772 000 000)')),
        if (m == 'Card' || m == 'Bank Transfer')
          TextField(controller: ref, decoration: InputDecoration(labelText: m == 'Card' ? 'Card approval / last 4 digits' : 'Transfer reference')),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: busy ? null : () => _pay(s),
          child: busy ? const CircularProgressIndicator() : const Text('Pay Now'),
        ),
      ]),
    );
  }

  Future<void> _pay(AppState s) async {
    final m = s.method;
    if (m == 'Cash' && (int.tryParse(tendered.text) ?? 0) < s.total) return _msg('Amount received is less than the total');
    if (m == 'Mobile Money' && phone.text.length < 9) return _msg('Enter a valid phone number');
    setState(() => busy = true);
    // Integration point: call MTN MoMo / Airtel Money / card gateway here (needs internet).
    // Cash always works offline. When offline, card/mobile money should be recorded as "pending".
    final reference = m == 'Mobile Money' ? phone.text : ref.text;
    final total = s.total;
    final id = await s.completeSale(method: m, reference: reference);
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 48),
        title: const Text('Payment successful'),
        content: Text('Receipt #$id\n${s.businessName}\nTotal: ${ugx(total)}\nMethod: $m\n\n${s.settings['receipt_footer'] ?? ''}', textAlign: TextAlign.center),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
      ),
    );
    if (mounted) Navigator.popUntil(context, (r) => r.isFirst);
  }

  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
}
