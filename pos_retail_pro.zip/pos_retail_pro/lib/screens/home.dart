import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../util.dart';
import 'sales.dart';
import 'manage.dart';
import 'settings.dart';
import 'reports.dart';

/// Bottom navigation shell: Home, Sales, Inventory, Customers, More
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardScreen(onTab: (i) => setState(() => tab = i)),
      const ProductsScreen(),
      const InventoryScreen(),
      const CustomersScreen(),
      const SettingsScreen(),
    ];
    return Scaffold(
      body: Column(children: [
        if (!context.watch<AppState>().online) const OfflineBanner(),
        Expanded(child: IndexedStack(index: tab, children: pages)),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Sales'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Inventory'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Customers'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});
  @override
  Widget build(BuildContext context) {
    final pending = context.watch<AppState>().pendingSync;
    return Material(
      color: Colors.orange.shade700,
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfflineScreen())),
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              const Icon(Icons.wifi_off, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Expanded(child: Text('Offline mode - $pending sale(s) waiting to sync', style: const TextStyle(color: Colors.white))),
            ]),
          ),
        ),
      ),
    );
  }
}

/// 3. Home / Dashboard
class DashboardScreen extends StatelessWidget {
  final void Function(int) onTab;
  const DashboardScreen({super.key, required this.onTab});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final h = DateTime.now().hour;
    final greet = h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';
    final cs = Theme.of(context).colorScheme;
    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(greet, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(s.settings['owner'] ?? 'Business Owner', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ])),
          IconButton(
            icon: Badge(isLabelVisible: s.pendingSync > 0, label: Text('${s.pendingSync}'), child: const Icon(Icons.notifications_none)),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfflineScreen())),
          ),
          const CircleAvatar(child: Icon(Icons.person)),
        ]),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("Today's Sales", style: TextStyle(color: Colors.white70)),
              Text(ugx(s.todaySales), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
            ])),
            const Icon(Icons.bar_chart, color: Colors.white, size: 36),
          ]),
        ),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 2, mainAxisSpacing: 10, crossAxisSpacing: 10,
          children: [
            _tile(context, Icons.shopping_cart, 'New Sale', () => onTab(1)),
            _tile(context, Icons.inventory_2, 'Inventory', () => onTab(2)),
            _tile(context, Icons.people, 'Customers', () => onTab(3)),
            _tile(context, Icons.bar_chart, 'Reports', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportsScreen()))),
          ],
        ),
        const SizedBox(height: 16),
        const Text('Recent Transactions', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        if (s.recent.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No sales yet')),
        for (final r in s.recent)
          Card(
            child: ListTile(
              leading: Icon(_methodIcon(r.method), color: cs.primary),
              title: Text('${r.method} Sale'),
              subtitle: Text(r.createdAt.substring(11, 16)),
              trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(ugx(r.total), style: const TextStyle(fontWeight: FontWeight.bold)),
                Icon(r.synced == 1 ? Icons.cloud_done : Icons.cloud_off, size: 14, color: r.synced == 1 ? Colors.green : Colors.orange),
              ]),
            ),
          ),
      ]),
    );
  }

  Widget _tile(BuildContext c, IconData i, String t, VoidCallback f) => Card(
        child: InkWell(
          onTap: f,
          borderRadius: BorderRadius.circular(12),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(i, color: Theme.of(c).colorScheme.primary),
            const SizedBox(height: 4),
            Text(t),
          ]),
        ),
      );
}

IconData _methodIcon(String m) => switch (m) {
      'Card' => Icons.credit_card,
      'Mobile Money' => Icons.phone_android,
      'Bank Transfer' => Icons.account_balance,
      _ => Icons.payments,
    };
