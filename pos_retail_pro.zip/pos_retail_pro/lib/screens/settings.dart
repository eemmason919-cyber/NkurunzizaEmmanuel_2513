import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import 'auth.dart';
import 'reports.dart';

/// 10. Settings
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SafeArea(
      child: ListView(children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('Settings', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(s.settings['owner'] ?? 'Business Owner'),
          subtitle: Text(s.businessName),
        ),
        const Divider(),
        ListTile(leading: const Icon(Icons.store_outlined), title: const Text('Business Profile'), trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BusinessProfileScreen()))),
        ListTile(leading: const Icon(Icons.bar_chart), title: const Text('Reports & Analytics'), trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportsScreen()))),
        ListTile(
          leading: Icon(s.online ? Icons.cloud_done_outlined : Icons.wifi_off),
          title: const Text('Sync status'),
          subtitle: Text(s.online ? 'Online - ${s.pendingSync} pending' : 'Offline - ${s.pendingSync} pending'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OfflineScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.privacy_tip_outlined),
          title: const Text('Privacy & Data Protection'),
          onTap: () => showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Privacy'),
              content: const Text('Passwords are stored as salted hashes. Session tokens are kept in the device secure keystore. Customer data is limited to name and phone and is used only for sales records, in line with the Uganda Data Protection and Privacy Act, 2019.'),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
            ),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.logout),
          title: const Text('Log out'),
          onTap: () async {
            await const FlutterSecureStorage().delete(key: 'session');
            if (context.mounted) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const SplashScreen()), (_) => false);
            }
          },
        ),
      ]),
    );
  }
}

/// 11. Offline mode
class OfflineScreen extends StatelessWidget {
  const OfflineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Connection')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          CircleAvatar(radius: 50, backgroundColor: Colors.grey.shade200, child: Icon(s.online ? Icons.cloud_done : Icons.wifi_off, size: 48)),
          const SizedBox(height: 16),
          Text(s.online ? 'You are online' : 'You are offline', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(s.online
              ? '${s.pendingSync} transaction(s) waiting to sync.'
              : 'You can keep selling. Transactions are saved on this device and will sync automatically when the connection returns.\n\nPending: ${s.pendingSync}',
              textAlign: TextAlign.center),
          const SizedBox(height: 24),
          if (s.online) FilledButton(onPressed: s.sync, child: const Text('Sync now')),
          if (!s.online) FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Continue Selling')),
        ]),
      ),
    );
  }
}

/// 12. Business Profile (customizes the app per business)
class BusinessProfileScreen extends StatefulWidget {
  const BusinessProfileScreen({super.key});
  @override
  State<BusinessProfileScreen> createState() => _BusinessProfileScreenState();
}

class _BusinessProfileScreenState extends State<BusinessProfileScreen> {
  late final TextEditingController name, owner, tax, footer;
  String type = 'Retail Store';
  static const types = ['Retail Store', 'Supermarket', 'Pharmacy', 'Restaurant', 'Hardware', 'Other'];

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>().settings;
    name = TextEditingController(text: s['business_name']);
    owner = TextEditingController(text: s['owner']);
    tax = TextEditingController(text: s['tax_rate']);
    footer = TextEditingController(text: s['receipt_footer']);
    type = types.contains(s['business_type']) ? s['business_type']! : 'Other';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Business Profile')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Business Name')),
        const SizedBox(height: 12),
        TextField(controller: owner, decoration: const InputDecoration(labelText: 'Owner Name')),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: type,
          decoration: const InputDecoration(labelText: 'Business Type'),
          items: [for (final t in types) DropdownMenuItem(value: t, child: Text(t))],
          onChanged: (v) => setState(() => type = v ?? type),
        ),
        const SizedBox(height: 12),
        TextField(controller: tax, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tax rate (%)')),
        const SizedBox(height: 12),
        TextField(controller: footer, decoration: const InputDecoration(labelText: 'Receipt footer')),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () async {
            await context.read<AppState>().saveSettings({
              'business_name': name.text.trim(), 'owner': owner.text.trim(), 'business_type': type,
              'tax_rate': '${int.tryParse(tax.text) ?? 18}', 'receipt_footer': footer.text.trim(),
            });
            if (context.mounted) Navigator.pop(context);
          },
          child: const Text('Save'),
        ),
      ]),
    );
  }
}
