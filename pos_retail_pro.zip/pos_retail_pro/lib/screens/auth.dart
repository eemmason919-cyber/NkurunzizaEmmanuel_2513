import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import 'home.dart';

const _storage = FlutterSecureStorage();

/// 1. Splash / Welcome
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final session = await _storage.read(key: 'session');
    if (session != null && mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeShell()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Spacer(),
            Icon(Icons.shopping_cart, size: 90, color: cs.primary),
            const SizedBox(height: 16),
            const Text('POS Retail Pro', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Manage your business\nanytime, anywhere', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)),
            const Spacer(),
            FilledButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
              child: const Text('Get Started'),
            ),
            const SizedBox(height: 24),
            Text('Version 1.0.0', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

/// 2. Login
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(), pw = TextEditingController();
  bool hide = true, remember = false, busy = false;

  Future<void> _login({bool signUp = false}) async {
    if (email.text.isEmpty || pw.text.length < 6) {
      _msg('Enter your email/phone and a password of at least 6 characters');
      return;
    }
    setState(() => busy = true);
    final app = context.read<AppState>();
    final ok = signUp ? await app.signUp(email.text, pw.text) : await app.login(email.text, pw.text);
    if (!mounted) return;
    setState(() => busy = false);
    if (!ok) {
      _msg(signUp ? 'Account already exists' : 'Invalid credentials');
      return;
    }
    if (remember) await _storage.write(key: 'session', value: DateTime.now().toIso8601String());
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeShell()), (_) => false);
  }

  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.transparent),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Login', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        Text('Sign in to your account', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 20),
        TextField(controller: email, keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(prefixIcon: Icon(Icons.email_outlined), hintText: 'Email or Phone')),
        const SizedBox(height: 12),
        TextField(controller: pw, obscureText: hide,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.lock_outline), hintText: 'Password',
              suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => hide = !hide)),
            )),
        Row(children: [
          Checkbox(value: remember, onChanged: (v) => setState(() => remember = v ?? false)),
          const Text('Remember me'),
          const Spacer(),
          TextButton(onPressed: () => _msg('Password reset requires the online backend'), child: const Text('Forgot password?')),
        ]),
        FilledButton(onPressed: busy ? null : _login, child: busy ? const CircularProgressIndicator() : const Text('Login')),
        const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Center(child: Text('OR'))),
        OutlinedButton.icon(onPressed: () => _msg('Add google_sign_in + Firebase to enable'), icon: const Icon(Icons.g_mobiledata, size: 28), label: const Text('Continue with Google')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: () => _msg('Add sign_in_with_apple to enable'), icon: const Icon(Icons.apple), label: const Text('Continue with Apple')),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text("Don't have an account?"),
          TextButton(onPressed: () => _login(signUp: true), child: const Text('Sign Up')),
        ]),
        Center(child: Text('Demo: owner@business.com / admin123', style: TextStyle(color: Colors.grey.shade500, fontSize: 12))),
      ]),
    );
  }
}
