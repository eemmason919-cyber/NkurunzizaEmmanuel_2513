import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../util.dart';

/// 7. Inventory (Stock / Low Stock / Categories)
class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});
  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final match = s.products.where((p) => p.name.toLowerCase().contains(q.toLowerCase())).toList();
    final cats = <String, int>{};
    for (final p in s.products) {
      cats[p.category] = (cats[p.category] ?? 0) + 1;
    }
    return DefaultTabController(
      length: 3,
      child: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Row(children: [
                const Expanded(child: Text('Inventory', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                IconButton.filled(icon: const Icon(Icons.add), onPressed: () => _edit(context, null)),
              ]),
              const SizedBox(height: 8),
              TextField(onChanged: (v) => setState(() => q = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search inventory...')),
            ]),
          ),
          const TabBar(tabs: [Tab(text: 'Stock'), Tab(text: 'Low Stock'), Tab(text: 'Categories')]),
          Expanded(
            child: TabBarView(children: [
              _list(context, match),
              _list(context, match.where((p) => p.low).toList()),
              ListView(children: [for (final e in cats.entries) ListTile(leading: const Icon(Icons.category_outlined), title: Text(e.key), trailing: Text('${e.value} items'))]),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _list(BuildContext context, List<Product> items) => ListView(children: [
        for (final p in items)
          ListTile(
            title: Text(p.name),
            subtitle: Text('Stock: ${p.stock}   Reorder: ${p.reorder}'),
            trailing: p.low ? const Chip(label: Text('Low'), backgroundColor: Color(0xFFFFE0B2)) : Text(ugx(p.price)),
            onTap: () => _edit(context, p),
          ),
      ]);

  void _edit(BuildContext context, Product? p) {
    final name = TextEditingController(text: p?.name), cat = TextEditingController(text: p?.category ?? 'Groceries');
    final price = TextEditingController(text: '${p?.price ?? ''}'), cost = TextEditingController(text: '${p?.cost ?? ''}');
    final stock = TextEditingController(text: '${p?.stock ?? ''}'), reorder = TextEditingController(text: '${p?.reorder ?? 10}');
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(p == null ? 'Add Product' : 'Edit Product', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
            const SizedBox(height: 8),
            TextField(controller: cat, decoration: const InputDecoration(labelText: 'Category')),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: cost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cost'))),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stock'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: reorder, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Reorder level'))),
            ]),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                if (name.text.trim().isEmpty) return;
                await context.read<AppState>().saveProduct(
                      id: p?.id, name: name.text.trim(), category: cat.text.trim(),
                      price: int.tryParse(price.text) ?? 0, cost: int.tryParse(cost.text) ?? 0,
                      stock: int.tryParse(stock.text) ?? 0, reorder: int.tryParse(reorder.text) ?? 0);
                if (context.mounted) Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ]),
        ),
      ),
    );
  }
}

/// 8. Customers
class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override
  State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = s.customers.where((c) => c.name.toLowerCase().contains(q.toLowerCase()) || c.phone.contains(q)).toList();
    return SafeArea(
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(children: [
            Row(children: [
              const Expanded(child: Text('Customers', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
              IconButton.filled(icon: const Icon(Icons.person_add), onPressed: () => _add(context)),
            ]),
            const SizedBox(height: 8),
            TextField(onChanged: (v) => setState(() => q = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search customers...')),
          ]),
        ),
        Expanded(
          child: ListView(children: [
            for (final c in list)
              ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(c.name), subtitle: Text(c.phone), trailing: const Icon(Icons.chevron_right)),
          ]),
        ),
      ]),
    );
  }

  void _add(BuildContext context) {
    final n = TextEditingController(), p = TextEditingController();
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Add Customer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 8),
          TextField(controller: p, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone')),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () async {
              if (n.text.trim().isEmpty) return;
              await context.read<AppState>().addCustomer(n.text.trim(), p.text.trim());
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ]),
      ),
    );
  }
}
