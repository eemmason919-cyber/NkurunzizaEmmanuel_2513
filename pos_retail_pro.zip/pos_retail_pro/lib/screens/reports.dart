import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../util.dart';

/// 9. Reports (Sales / Inventory / Customers  x  7 Days / 30 Days)
class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int days = 7;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(title: const Text('Reports'), bottom: const TabBar(tabs: [Tab(text: 'Sales'), Tab(text: 'Inventory'), Tab(text: 'Customers')])),
        body: TabBarView(children: [_sales(context), _inventory(context), _customers(context)]),
      ),
    );
  }

  Widget _sales(BuildContext context) {
    final s = context.watch<AppState>(); // rebuilds when a sale completes => real-time
    return FutureBuilder<ReportData>(
      key: ValueKey('${s.todaySales}-$days-${s.recent.length}'),
      future: s.report(days),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final r = snap.data!;
        return ListView(padding: const EdgeInsets.all(16), children: [
          SegmentedButton<int>(
            segments: const [ButtonSegment(value: 7, label: Text('7 Days')), ButtonSegment(value: 30, label: Text('30 Days'))],
            selected: {days},
            onSelectionChanged: (v) => setState(() => days = v.first),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Total Sales'),
                Text(ugx(r.total), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                Text('${r.count} transactions'),
                const SizedBox(height: 16),
                SizedBox(
                  height: 160,
                  child: r.byDay.isEmpty
                      ? const Center(child: Text('No data for this period'))
                      : BarChart(BarChartData(
                          titlesData: FlTitlesData(
                            leftTitles: const AxisTitles(),
                            topTitles: const AxisTitles(),
                            rightTitles: const AxisTitles(),
                            bottomTitles: AxisTitles(sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (v, _) {
                                final i = v.toInt();
                                if (i < 0 || i >= r.byDay.length) return const SizedBox();
                                return Text(r.byDay[i].key.substring(8), style: const TextStyle(fontSize: 10));
                              },
                            )),
                          ),
                          borderData: FlBorderData(show: false),
                          gridData: const FlGridData(show: false),
                          barGroups: [for (var i = 0; i < r.byDay.length; i++) BarChartGroupData(x: i, barRods: [BarChartRodData(toY: r.byDay[i].value.toDouble(), width: 14)])],
                        )),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Top Products', style: TextStyle(fontWeight: FontWeight.bold)),
          for (final t in r.top) ListTile(dense: true, title: Text(t.key), trailing: Text('${t.value} sold')),
        ]);
      },
    );
  }

  Widget _inventory(BuildContext context) {
    final s = context.watch<AppState>();
    final value = s.products.fold<int>(0, (a, p) => a + p.stock * p.cost);
    final low = s.products.where((p) => p.low).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(title: const Text('Stock value (at cost)'), trailing: Text(ugx(value), style: const TextStyle(fontWeight: FontWeight.bold)))),
      Card(child: ListTile(title: const Text('Products'), trailing: Text('${s.products.length}'))),
      Card(child: ListTile(title: const Text('Low stock items'), trailing: Text('${low.length}'))),
      for (final p in low) ListTile(dense: true, title: Text(p.name), subtitle: Text('Only ${p.stock} left')),
    ]);
  }

  Widget _customers(BuildContext context) {
    final s = context.watch<AppState>();
    return FutureBuilder<List<Map<String, Object?>>>(
      key: ValueKey(s.recent.length),
      future: s.topCustomers(),
      builder: (_, snap) {
        final rows = snap.data ?? [];
        return ListView(padding: const EdgeInsets.all(16), children: [
          Card(child: ListTile(title: const Text('Total customers'), trailing: Text('${s.customers.length}'))),
          const Text('Top customers', style: TextStyle(fontWeight: FontWeight.bold)),
          if (rows.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('No customer sales yet')),
          for (final r in rows) ListTile(title: Text('${r['name']}'), subtitle: Text('${r['n']} purchases'), trailing: Text(ugx((r['spent'] as num)))),
        ]);
      },
    );
  }
}
