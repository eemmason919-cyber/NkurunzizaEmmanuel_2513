import 'package:intl/intl.dart';

final _n = NumberFormat('#,##0');
String ugx(num v) => 'UGX ${_n.format(v)}';
