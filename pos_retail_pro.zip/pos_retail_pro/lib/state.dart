import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import 'db.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  List<Product> products = [];
  List<Customer> customers = [];
  List<SaleRow> recent = [];
  Map<String, String> settings = {};
  int todaySales = 0, pendingSync = 0;
  bool online = true;

  final Map<int, CartLine> cart = {};
  Customer? customer; // null = walk-in
  String method = 'Cash';

  late Database _db;
  StreamSubscription? _sub;

  int get taxRate => int.tryParse(settings['tax_rate'] ?? '18') ?? 18;
  String get businessName => settings['business_name'] ?? 'My Store';

  Future<void> init() async {
    _db = await Db.get();
    await refresh();
    final c = await Connectivity().checkConnectivity();
    online = !c.contains(ConnectivityResult.none);
    _sub = Connectivity().onConnectivityChanged.listen((r) {
      online = !r.contains(ConnectivityResult.none);
      if (online) sync();
      notifyListeners();
    });
    if (online) sync();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> refresh() async {
    products = (await _db.query('products', orderBy: 'name')).map(Product.fromMap).toList();
    customers = (await _db.query('customers', orderBy: 'name')).map(Customer.fromMap).toList();
    settings = {for (final r in await _db.query('settings')) r['key'] as String: r['value'] as String};
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day).toIso8601String();
    final t = await _db.rawQuery('SELECT COALESCE(SUM(total),0) t FROM sales WHERE created_at >= ?', [start]);
    todaySales = (t.first['t'] as num).toInt();
    recent = (await _db.query('sales', orderBy: 'id DESC', limit: 5))
        .map((m) => SaleRow(m['id'] as int, m['total'] as int, m['method'] as String, m['created_at'] as String, (m['synced'] as int?) ?? 0))
        .toList();
    pendingSync = Sqflite.firstIntValue(await _db.rawQuery('SELECT COUNT(*) FROM sync_queue')) ?? 0;
    notifyListeners();
  }

  // ---------- Auth ----------
  Future<bool> login(String email, String pw) async {
    final r = await _db.query('users', where: 'email = ? AND hash = ?', whereArgs: [email.trim().toLowerCase(), hashPw(pw)]);
    return r.isNotEmpty;
  }

  Future<bool> signUp(String email, String pw) async {
    try {
      await _db.insert('users', {'email': email.trim().toLowerCase(), 'hash': hashPw(pw), 'role': 'cashier'});
      return true;
    } catch (_) {
      return false;
    }
  }

  // ---------- Cart ----------
  int get subtotal => cart.values.fold(0, (s, l) => s + l.total);
  int get tax => (subtotal * taxRate / 100).round();
  int get total => subtotal + tax;
  int get cartCount => cart.values.fold(0, (s, l) => s + l.qty);

  void addToCart(Product p) {
    final line = cart[p.id];
    if (line == null) {
      if (p.stock > 0) cart[p.id] = CartLine(p, 1);
    } else if (line.qty < p.stock) {
      line.qty++;
    }
    notifyListeners();
  }

  void changeQty(Product p, int delta) {
    final line = cart[p.id];
    if (line == null) return;
    line.qty += delta;
    if (line.qty <= 0) cart.remove(p.id);
    if (line.qty > p.stock) line.qty = p.stock;
    notifyListeners();
  }

  void setCustomer(Customer? c) {
    customer = c;
    notifyListeners();
  }

  void setMethod(String m) {
    method = m;
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    customer = null;
    method = 'Cash';
    notifyListeners();
  }

  // ---------- Sale (atomic, works fully offline) ----------
  Future<int> completeSale({required String method, String? reference, int? paid}) async {
    final lines = cart.values.toList();
    final sub = subtotal, tx = tax, tot = total;
    final custId = customer?.id;
    late int saleId;
    await _db.transaction((t) async {
      saleId = await t.insert('sales', {
        'total': tot, 'tax': tx, 'customer_id': custId, 'method': method,
        'created_at': DateTime.now().toIso8601String(), 'synced': 0,
      });
      for (final l in lines) {
        await t.insert('sale_items', {
          'sale_id': saleId, 'product_id': l.product.id,
          'name': l.product.name, 'qty': l.qty, 'price': l.product.price,
        });
        await t.rawUpdate('UPDATE products SET stock = stock - ? WHERE id = ?', [l.qty, l.product.id]);
      }
      await t.insert('payments', {'sale_id': saleId, 'method': method, 'amount': tot, 'reference': reference});
      await t.insert('sync_queue', {'entity': 'sale', 'entity_id': saleId, 'created_at': DateTime.now().toIso8601String()});
    });
    assert(sub + tx == tot);
    clearCart();
    await refresh();
    if (online) sync();
    return saleId;
  }

  // ---------- Inventory / customers / settings ----------
  Future<void> saveProduct({int? id, required String name, required String category, required int price, required int cost, required int stock, required int reorder}) async {
    final v = {'name': name, 'category': category, 'price': price, 'cost': cost, 'stock': stock, 'reorder': reorder};
    if (id == null) {
      await _db.insert('products', v);
    } else {
      await _db.update('products', v, where: 'id = ?', whereArgs: [id]);
    }
    await refresh();
  }

  Future<void> restock(Product p, int qty) async {
    await _db.rawUpdate('UPDATE products SET stock = stock + ? WHERE id = ?', [qty, p.id]);
    await refresh();
  }

  Future<void> addCustomer(String name, String phone) async {
    await _db.insert('customers', {'name': name, 'phone': phone});
    await refresh();
  }

  Future<void> saveSettings(Map<String, String> m) async {
    for (final e in m.entries) {
      await _db.insert('settings', {'key': e.key, 'value': e.value}, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await refresh();
  }

  // ---------- Sync ----------
  /// Replace the body of this method with real REST/Firebase calls.
  /// Pattern: read sync_queue -> POST each record -> on success mark synced & delete from queue.
  Future<void> sync() async {
    if (!online) return;
    final q = await _db.query('sync_queue');
    for (final row in q) {
      // await api.pushSale(row['entity_id']);   <-- real backend call goes here
      await _db.update('sales', {'synced': 1}, where: 'id = ?', whereArgs: [row['entity_id']]);
      await _db.delete('sync_queue', where: 'id = ?', whereArgs: [row['id']]);
    }
    pendingSync = Sqflite.firstIntValue(await _db.rawQuery('SELECT COUNT(*) FROM sync_queue')) ?? 0;
    await refresh();
  }

  // ---------- Reports ----------
  Future<ReportData> report(int days) async {
    final from = DateTime.now().subtract(Duration(days: days - 1));
    final start = DateTime(from.year, from.month, from.day).toIso8601String();
    final t = (await _db.rawQuery('SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE created_at >= ?', [start])).first;
    final byDay = (await _db.rawQuery('SELECT substr(created_at,1,10) d, SUM(total) t FROM sales WHERE created_at >= ? GROUP BY d ORDER BY d', [start]))
        .map((r) => MapEntry(r['d'] as String, (r['t'] as num).toInt())).toList();
    final top = (await _db.rawQuery('SELECT si.name n, SUM(si.qty) q FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE s.created_at >= ? GROUP BY si.name ORDER BY q DESC LIMIT 5', [start]))
        .map((r) => MapEntry(r['n'] as String, (r['q'] as num).toInt())).toList();
    return ReportData((t['t'] as num).toInt(), (t['c'] as num).toInt(), byDay, top);
  }

  Future<List<Map<String, Object?>>> topCustomers() => _db.rawQuery(
      'SELECT c.name name, COUNT(s.id) n, SUM(s.total) spent FROM sales s JOIN customers c ON c.id = s.customer_id GROUP BY c.id ORDER BY spent DESC LIMIT 5');
}
