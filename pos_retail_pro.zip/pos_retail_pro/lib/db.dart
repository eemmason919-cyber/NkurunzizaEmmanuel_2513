import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';

String hashPw(String pw) => sha256.convert(utf8.encode('pos-salt:$pw')).toString();

class Db {
  static Database? _db;

  static Future<Database> get() async {
    if (_db != null) return _db!;
    _db = await openDatabase(
      join(await getDatabasesPath(), 'pos_retail_pro.db'),
      version: 1,
      onCreate: (db, v) async {
        await db.execute('CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, hash TEXT, role TEXT)');
        await db.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT, price INTEGER, cost INTEGER, stock INTEGER, reorder INTEGER)');
        await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)');
        await db.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, total INTEGER, tax INTEGER, customer_id INTEGER, method TEXT, created_at TEXT, synced INTEGER DEFAULT 0)');
        await db.execute('CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, name TEXT, qty INTEGER, price INTEGER)');
        await db.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, method TEXT, amount INTEGER, reference TEXT)');
        await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
        await db.execute('CREATE TABLE sync_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, entity TEXT, entity_id INTEGER, created_at TEXT)');

        // Seed data taken from the wireframe
        await db.insert('users', {'email': 'owner@business.com', 'hash': hashPw('admin123'), 'role': 'admin'});
        final products = [
          ['Coca Cola 500ml', 'Beverages', 2500, 1800, 50, 20],
          ['Sprite 500ml', 'Beverages', 2500, 1800, 40, 20],
          ['Water 500ml', 'Beverages', 1500, 900, 100, 30],
          ['Bread', 'Groceries', 3000, 2200, 30, 10],
          ['Chips', 'Snacks', 2000, 1300, 45, 15],
        ];
        for (final p in products) {
          await db.insert('products', {'name': p[0], 'category': p[1], 'price': p[2], 'cost': p[3], 'stock': p[4], 'reorder': p[5]});
        }
        await db.insert('customers', {'name': 'John Mwangi', 'phone': '+256 700 123 456'});
        await db.insert('customers', {'name': 'Sarah Nakato', 'phone': '+256 772 987 654'});
        final defaults = {
          'business_name': 'My Store', 'business_type': 'Retail Store',
          'tax_rate': '18', 'currency': 'UGX', 'owner': 'Business Owner',
          'receipt_footer': 'Thank you for shopping with us!',
        };
        for (final e in defaults.entries) {
          await db.insert('settings', {'key': e.key, 'value': e.value});
        }
      },
    );
    return _db!;
  }
}
