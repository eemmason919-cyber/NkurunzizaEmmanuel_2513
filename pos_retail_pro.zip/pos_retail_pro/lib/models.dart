class Product {
  final int id;
  final String name, category;
  final int price, cost, stock, reorder;
  Product(this.id, this.name, this.category, this.price, this.cost, this.stock, this.reorder);
  factory Product.fromMap(Map<String, Object?> m) => Product(
      m['id'] as int, m['name'] as String, m['category'] as String,
      m['price'] as int, m['cost'] as int, m['stock'] as int, m['reorder'] as int);
  bool get low => stock <= reorder;
}

class Customer {
  final int id;
  final String name, phone;
  Customer(this.id, this.name, this.phone);
  factory Customer.fromMap(Map<String, Object?> m) =>
      Customer(m['id'] as int, m['name'] as String, m['phone'] as String);
}

class CartLine {
  final Product product;
  int qty;
  CartLine(this.product, this.qty);
  int get total => product.price * qty;
}

class SaleRow {
  final int id, total, synced;
  final String method, createdAt;
  SaleRow(this.id, this.total, this.method, this.createdAt, this.synced);
}

class ReportData {
  final int total, count;
  final List<MapEntry<String, int>> byDay;
  final List<MapEntry<String, int>> top;
  ReportData(this.total, this.count, this.byDay, this.top);
}
