# POS Retail Pro (Flutter)

Offline-first POS app for Android and iOS, built from the 12-screen "POS Retail Pro" wireframe.

## Run
```
flutter create . --platforms=android,ios   # generates android/ and ios/ folders (keeps lib/ and pubspec.yaml)
flutter pub get
flutter run
```
Demo login: owner@business.com / admin123

## Android permission
connectivity_plus needs no extra permission on current versions. For real payment gateways add INTERNET in AndroidManifest.xml (flutter create adds it).

## Screens -> files
1 Splash, 2 Login: lib/screens/auth.dart
3 Dashboard: lib/screens/home.dart
4 Products, 5 Checkout, 6 Payment: lib/screens/sales.dart
7 Inventory, 8 Customers: lib/screens/manage.dart
9 Reports: lib/screens/reports.dart
10 Settings, 11 Offline, 12 Business Profile: lib/screens/settings.dart

## Where to plug in real services
- AppState.sync() in lib/state.dart: push the sync_queue to your REST/Firebase backend
- PaymentScreen._pay() in lib/screens/sales.dart: MTN MoMo / Airtel / card gateway calls
